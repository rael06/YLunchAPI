namespace YLunch.Domain.ModelsAggregate.RestaurantAggregate
{
    public class RestaurantOwner : RestaurantUser
    {
    }
}
