using System.ComponentModel.DataAnnotations;

namespace YLunch.Domain.ModelsAggregate.RestaurantAggregate
{
    public class RestaurantProductTag
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
