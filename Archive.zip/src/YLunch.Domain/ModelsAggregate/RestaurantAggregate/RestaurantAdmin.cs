namespace YLunch.Domain.ModelsAggregate.RestaurantAggregate
{
    public class RestaurantAdmin : RestaurantUser
    {
    }
}
