namespace YLunch.Domain.ModelsAggregate.RestaurantAggregate
{
    public class RestaurantEmployee : RestaurantUser
    {
    }
}
