namespace YLunch.Domain.DTO.UserModels.Registration
{
    public class RestaurantOwnerCreationDto : UserCreationDto
    {
        public override bool IsValid()
        {
            throw new System.NotImplementedException();
        }
    }
}
