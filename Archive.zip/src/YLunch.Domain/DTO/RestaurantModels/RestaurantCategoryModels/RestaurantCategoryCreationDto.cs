using System;
using YLunch.Domain.ModelsAggregate.RestaurantAggregate;

namespace YLunch.Domain.DTO.RestaurantModels.RestaurantCategoryModels
{
    public class RestaurantCategoryCreationDto
    {
        public string Name { get; set; }
    }
}
