namespace YLunch.DomainShared.RestaurantAggregate.Enums
{
    public enum CustomerFamily
    {
        Student,
        Teacher,
        Other
    }
}
