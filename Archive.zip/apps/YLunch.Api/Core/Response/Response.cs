namespace YLunch.Api.Core.Response
{
    public class Response
    {
        public string Status { get; set; }
        public string Message { get; set; }
    }
}
