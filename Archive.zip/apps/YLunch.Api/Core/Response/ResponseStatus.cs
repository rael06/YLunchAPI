namespace YLunch.Api.Core.Response
{
    public static class ResponseStatus
    {
        public const string Error = "Error";
        public const string Success = "Success";
    }
}
